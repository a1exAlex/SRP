import Foundation
import BigInt
import Cryptor


/// SRP Клиент; сторона, которая инициализирует аутентификацию и
/// должен подтвердить наличие правильного пароля.
public class Client {
    let a: BigUInt
    let A: BigUInt

    let group: Group
    let algorithm: Digest.Algorithm

    let username: String
    var password: String?
    var precomputedX: BigUInt?

    var HAMK: Data?
    var K: Data?

    
    /// аутентифицирован ли сеанс, то есть пароль
    /// был проверен сервером и является подтверждением действительного сеанса
    /// ключ предоставлен сервером. Если `true`,` sessionKey`
    /// также доступен.
    
    public private(set) var isAuthenticated = false

    private init(
        username: String,
        group: Group = .N2048,
        algorithm: Digest.Algorithm = .sha1,
        privateKey: Data? = nil)
    {
        self.username = username
        self.group = group
        self.algorithm = algorithm
        if let privateKey = privateKey {
            a = BigUInt(privateKey)
        } else {
            a = BigUInt(Data(bytes: try! Random.generate(byteCount: 128)))
        }
        // A = g^a % N
        A = group.g.power(a, modulus: group.N)
    }
    
    /// Инициализировать клиентскую SRP-сторону паролем.
              ///
              /// - Параметры:
              /// - имя пользователя: имя пользователя пользователя.
              /// - пароль: пароль пользователя.
              /// - группа: какой `Group` использовать, должен быть одинаковым для
              /// сервер, а также предварительно сохраненный ключ подтверждения.
              /// - алгоритм: какой `Digest.Algorithm` использовать, опять же
              /// должен быть таким же для сервера, как и для предварительно сохраненных
              /// validKey.
              /// - privateKey: (необязательно) настраиваемый закрытый ключ (a); если обеспечивает
              /// закрытый ключ `Client`, обязательно предоставьте
              /// хороший случайный ключ длиной не менее 32 байт. По умолчанию это
              /// генерируем закрытый ключ размером 128 байт. Вы НЕ ДОЛЖНЫ повторно использовать
              /// закрытый ключ между сессиями.
    public convenience init(
        username: String,
        password: String,
        group: Group = .N2048,
        algorithm: Digest.Algorithm = .sha1,
        privateKey: Data? = nil)
    {
        self.init(username: username, group: group, algorithm: algorithm, privateKey: privateKey)
        self.password = password
    }

    /// Инициализация стороны SRP клиента с предварительно вычисленным x.
              ///
              /// - Параметры:
              /// - имя пользователя: имя пользователя пользователя.
              /// - precomputedX: предварительно вычисленный SRP x.
              /// - группа: какой `Group` использовать, должен быть одинаковым для
              /// сервер, а также предварительно сохраненный ключ подтверждения.
              /// - алгоритм: какой `Digest.Algorithm` использовать, опять же
              /// должен быть таким же для сервера, как и для предварительно сохраненных
              /// validKey.
              /// - privateKey: (необязательно) настраиваемый закрытый ключ (a); если обеспечивает
              /// закрытый ключ `Client`, обязательно предоставьте
              /// хороший случайный ключ длиной не менее 32 байт. По умолчанию это
              /// генерируем закрытый ключ размером 128 байт. Вы НЕ ДОЛЖНЫ повторно использовать
              /// закрытый ключ между сессиями.
    
    public convenience init(
        username: String,
        precomputedX: Data,
        group: Group = .N2048,
        algorithm: Digest.Algorithm = .sha1,
        privateKey: Data? = nil)
    {
        self.init(username: username, group: group, algorithm: algorithm, privateKey: privateKey)
        self.precomputedX = BigUInt(precomputedX)
    }


    /// Запускает аутентификацию.
    ///
    /// - Возвращает: `username` (I) и` publicKey` (A)
    public func startAuthentication() -> (username: String, publicKey: Data) {
        return (username, publicKey)
    }

    
    /// Обработка запроса, предоставленного сервером. Это устанавливает `sessionKey`
              /// и генерирует доказательство того, что он сгенерировал правильный пароль из пароля
              /// и вызов. После того, как сервер также доказал действительность их
              /// ключ `sessionKey` может быть использован.
              ///
              /// - Параметры:
              /// - соль: пользовательская соль (и)
              /// - publicKey: открытый ключ сервера (B)
              /// - Возвращает: ключ доказательства (M)
              /// - Выдает: `AuthenticationFailure.invalidPublicKey`, если сервер
              /// открытый ключ недействителен (т. е. B% N равно нулю).
    
    
    public func processChallenge(salt: Data, publicKey serverPublicKey: Data) throws -> Data {
        let H = Digest.hasher(algorithm)
        let N = group.N

        let B = BigUInt(serverPublicKey)

        guard B % N != 0 else {
            throw AuthenticationFailure.invalidPublicKey
        }

        let u = calculate_u(group: group, algorithm: algorithm, A: publicKey, B: serverPublicKey)
        let k = calculate_k(group: group, algorithm: algorithm)
        let x = self.precomputedX ?? calculate_x(algorithm: algorithm, salt: salt, username: username, password: password!)
        let v = calculate_v(group: group, x: x)

        // общий секрет
        // S = (B - kg ^ x) ^ (a + ux)
        // Обратите внимание, что v = g ^ x, и что B - kg ^ x может стать отрицательным, что
        // невозможно сохранить в BigUInt. Таким образом, мы добавим N к B_ и убедитесь, что кв
        // не больше чем N.
        let S = (B + N - k * v % N).power(a + u * x, modulus: N)

        // ключ сессии
        K = H(S.serialize())

       // проверка клиента
        let M = calculate_M(group: group, algorithm: algorithm, username: username, salt: salt, A: publicKey, B: serverPublicKey, K: K!)

       // проверка сервера
        HAMK = calculate_HAMK(algorithm: algorithm, A: publicKey, M: M, K: K!)
        return M
    }

    /// После того как сервер проверит, что пароль правильный,
    /// отправит подтверждение полученного сеансового ключа. Это проверено
    /// с нашей стороны и завершает сеанс аутентификации. После этого
    /// шаг, `sessionKey` доступен.
    
    /// - Параметр HAMK: доказательство того, что сервер получил то же самое
    /// ключ сеанса.
    /// - Броски:
    /// - `AuthenticationFailure.missingChallenge`, если этот метод
    /// вызывается перед вызовом `processChallenge`.
    /// - `AuthenticationFailure.keyProofMismatch`, если доказательство
    /// не соответствует нашему.
    
    public func verifySession(keyProof serverKeyProof: Data) throws {
        guard let HAMK = HAMK else {
            throw AuthenticationFailure.missingChallenge
        }
        guard HAMK == serverKeyProof else {
            throw AuthenticationFailure.keyProofMismatch
        }
        isAuthenticated = true
    }


    /// Открытый ключ клиента (A). Для каждой аутентификации
    /// сессия генерируется новый открытый ключ.
    public var publicKey: Data {
        return A.serialize()
    }
    
    /// Закрытый ключ клиента (а). Для каждой аутентификации
    /// сессия генерируется новый случайный закрытый ключ.
    public var privateKey: Data {
        return a.serialize()
    }

    /// Ключ сеанса (K), которым обмениваются во время аутентификации.
    /// Этот ключ может быть использован для шифрования дальнейшей связи
    /// между клиентом и сервером.
    public var sessionKey: Data? {
        guard isAuthenticated else {
            return nil
        }
        return K
    }
}
