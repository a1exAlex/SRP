import Foundation
import BigInt
import Cryptor

/// SRP Сервер; сторона, которая проверяет вызов / ответ Клиента
/// против известного верификатора пароля, сохраненного для пользователя.

public class Server {
    let b: BigUInt
    let B: BigUInt

    let salt: Data
    let username: String

    let v: BigUInt
    var K: Data?

    let group: Group
    let algorithm: Digest.Algorithm

    /// аутентифицирован ли сеанс, то есть пароль
    /// был проверен сервером и является подтверждением действительного сеанса
    /// ключ предоставлен сервером. Если `true`,` sessionKey`
    /// также доступен.


    public private(set) var isAuthenticated = false

    
    /// Инициализация стороны SRP сервера. Имя пользователя предоставляется
    /// Клиентом. Соль и проверка ключа были
    /// сохраняется до попытки аутентификации.
    ///
    /// - Параметры:
    /// - имя пользователя: имя пользователя (I), предоставленное клиентом.
    /// - соль: соль, сохраненная для этого имени пользователя.
    /// - verifyKey: ключ подтверждения (v) сохранен для этого
    /// имя пользователя.
    /// - группа: какой `Group` использовать, должен быть одинаковым для
    /// клиент, а также предварительно сохраненный ключ подтверждения.
    /// - алгоритм: какой `Digest.Algorithm` использовать, опять же
    /// должен быть таким же для клиента, как и предварительно сохраненный
    /// validKey.
    /// - privateKey: (необязательно) настраиваемый закрытый ключ (b); если обеспечивает
    /// закрытый ключ `Server`, не забудьте указать
    /// хороший случайный ключ длиной не менее 32 байт. По умолчанию это
    /// генерируем закрытый ключ размером 128 байт. Вы НЕ ДОЛЖНЫ повторно использовать
    /// закрытый ключ между сессиями. Однако закрытый ключ
    /// может использоваться совместно при запуске нескольких экземпляров и
    /// сеанс аутентификации может быть обработан несколькими
    /// экземпляры.
    public init(
        username: String,
        salt: Data,
        verificationKey: Data,
        group: Group = .N2048,
        algorithm: Digest.Algorithm = .sha1,
        privateKey: Data? = nil)
    {
        self.group = group
        self.algorithm = algorithm
        self.salt = salt
        self.username = username

        if let privateKey = privateKey {
            b = BigUInt(privateKey)
        } else {
            b = BigUInt(Data(bytes: try! Random.generate(byteCount: 128)))
        }
        let k = calculate_k(group: group, algorithm: algorithm)
        v = BigUInt(verificationKey)
        let N = group.N
        let g = group.g
        // B = (k*v + g^b) % N
        // В библиотеке BigInt нет x ^ y, но есть x ^ y% z, поэтому мы вычисляем B:
        // B = (k*v + g^b % N) % N
        B = ((k * v + g.power(b, modulus: N)) % N)
    }

    /// Возвращает вызов.
    ///
    /// - Возвращает: `salt` (s) и` publicKey` (B)
    public func getChallenge() -> (salt: Data, publicKey: Data) {
        return (salt, publicKey)
    }

    /// Убедитесь, что клиент сгенерировал правильный `sessionKey`
    /// от их пароля и задачи, которую мы предоставили. Мы будем генерировать
    /// также `sessionKey` и докажем клиенту, что у нас есть
    /// верификатора пароля и, следовательно, сгенерировал тот же `sessionKey`
    /// От этого.
    ///
    /// - Параметры:
    /// - clientPublicKey: открытый ключ клиента
    /// - clientKeyProof: клиентское доказательство `sessionKey`
    /// - Возвращает: наше доказательство `sessionKey` (H (A | M | K))
    /// - Броски:
    /// - `AuthenticationFailure.invalidPublicKey`, если клиент общедоступен
    /// ключ недействителен (т.е. B% N равен нулю).
    /// - `AuthenticationFailure.keyProofMismatch`, если доказательство
    /// не соответствует нашему.

    public func verifySession(publicKey clientPublicKey: Data, keyProof clientKeyProof: Data) throws -> Data {
        let u = calculate_u(group: group, algorithm: algorithm, A: clientPublicKey, B: publicKey)
        let A = BigUInt(clientPublicKey)
        let N = group.N

        guard A % N != 0 else {
            throw AuthenticationFailure.invalidPublicKey
        }

       // общий секрет
        // S = (Av^u) mod N
        let S = (A * v.power(u, modulus: N)).power(b, modulus: N)

        let H = Digest.hasher(algorithm)
        // K = H(S)
        K = H(S.serialize())

        let M = calculate_M(group: group, algorithm: algorithm, username: username, salt: salt, A: clientPublicKey, B: publicKey, K: K!)
        guard clientKeyProof == M else {
            throw AuthenticationFailure.keyProofMismatch
        }
        isAuthenticated = true

        return calculate_HAMK(algorithm: algorithm, A: clientPublicKey, M: M, K: sessionKey!)
    }

    /// Открытый ключ сервера (A). Для каждой аутентификации
    /// сессия генерируется новый открытый ключ.
    public var publicKey: Data {
        return B.serialize()
    }


    /// Закрытый ключ сервера (а). Для каждой аутентификации
    /// сессия генерируется новый случайный закрытый ключ.
    public var privateKey: Data {
        return b.serialize()
    }
    
    /// Ключ сеанса (K), которым обмениваются во время аутентификации.
    /// Этот ключ может быть использован для шифрования дальнейшей связи
    /// между клиентом и сервером.
    public var sessionKey: Data? {
        guard isAuthenticated else {
            return nil
        }
        return K
    }
}


